# BEATX Android v1
Native Kotlin + Jetpack Compose starter. UI/player controls are demo-only; no copyrighted music is bundled. Next: real local audio picker + Media3 playback, playlists, billing and ads.
