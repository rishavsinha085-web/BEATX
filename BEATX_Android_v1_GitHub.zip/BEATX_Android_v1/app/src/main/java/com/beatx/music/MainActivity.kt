package com.beatx.music
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Song(val title:String,val artist:String,val icon:String)
val songs=listOf(
 Song("Midnight Drive","BEATX Originals","🎵"),
 Song("Afterglow","Neon Waves","🌌"),
 Song("Voltage","BEATX Lab","⚡"),
 Song("Moonlight","Dream Circuit","🌙")
)

class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{BeatxApp()}}}

@Composable fun BeatxApp(){
 var selected by remember{mutableStateOf(0)}
 var playing by remember{mutableStateOf(false)}
 var liked by remember{mutableStateOf(false)}
 MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFFD06CFF),background=Color(0xFF09090D))){
  Surface(Modifier.fillMaxSize(),color=Color(0xFF09090D)){
   Column(Modifier.fillMaxSize().padding(horizontal=18.dp)){
    Row(Modifier.fillMaxWidth().padding(top=18.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
     Text("BEATX",fontSize=28.sp,fontWeight=FontWeight.Black);Text("⚙️",fontSize=22.sp)
    }
    Text("🔎  Search your music",color=Color(0xFF9999A5),modifier=Modifier.fillMaxWidth().padding(vertical=18.dp).background(Color(0xFF17171F),RoundedCornerShape(15.dp)).padding(14.dp))
    Box(Modifier.fillMaxWidth().height(255.dp).background(Brush.linearGradient(listOf(Color(0xFFFF5D8F),Color(0xFF6B38D8),Color(0xFF15152A))),RoundedCornerShape(25.dp)),contentAlignment=Alignment.Center){Text(songs[selected].icon,fontSize=82.sp)}
    Text(songs[selected].title,fontSize=25.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=16.dp))
    Text(songs[selected].artist,color=Color(0xFF9D9DA8))
    Slider(value=0.3f,onValueChange={},modifier=Modifier.padding(top=8.dp))
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.Center,verticalAlignment=Alignment.CenterVertically){
     Text("⏮",fontSize=25.sp,modifier=Modifier.clickable{selected=(selected-1+songs.size)%songs.size}.padding(14.dp))
     Button(onClick={playing=!playing},modifier=Modifier.size(60.dp),shape=CircleShape,contentPadding=PaddingValues(0.dp)){Text(if(playing)"Ⅱ" else "▶",fontSize=21.sp)}
     Text("⏭",fontSize=25.sp,modifier=Modifier.clickable{selected=(selected+1)%songs.size}.padding(14.dp))
    }
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(9.dp)){
     Tool(if(liked)"♥" else "♡","Favorite"){liked=!liked};Tool("🎚️","Equalizer"){};Tool("✨","AI Remix"){}
    }
    Text("Up Next",fontSize=19.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=20.dp,bottom=6.dp))
    LazyColumn(Modifier.weight(1f)){itemsIndexed(songs){i,s->Row(Modifier.fillMaxWidth().clickable{selected=i}.padding(vertical=7.dp),verticalAlignment=Alignment.CenterVertically){
     Box(Modifier.size(50.dp).background(Color(0xFF252536),RoundedCornerShape(11.dp)),contentAlignment=Alignment.Center){Text(s.icon,fontSize=21.sp)}
     Column(Modifier.weight(1f).padding(start=11.dp)){Text(s.title,fontWeight=FontWeight.Bold);Text(s.artist,color=Color(0xFF898995),fontSize=12.sp)}
     Text("▶",modifier=Modifier.padding(10.dp))
    }}}
    Row(Modifier.fillMaxWidth().padding(vertical=8.dp),horizontalArrangement=Arrangement.SpaceAround){
     listOf("⌂" to "Home","♫" to "Player","✦" to "AI Lab","♡" to "Library","☺" to "Profile").forEach{(a,b)->Column(horizontalAlignment=Alignment.CenterHorizontally){Text(a,fontSize=19.sp);Text(b,fontSize=10.sp,color=Color(0xFF9A9AA5))}}
    }
   }
  }
 }
}
@Composable fun RowScope.Tool(icon:String,label:String,onClick:()->Unit)=Column(Modifier.weight(1f).clickable{onClick()}.background(Color(0xFF17171F),RoundedCornerShape(14.dp)).padding(9.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(icon,fontSize=18.sp);Text(label,fontSize=11.sp)}
